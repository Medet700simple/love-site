document.getElementById('uploadPhoto').addEventListener('change', function(event) {
    const container = document.getElementById('photoContainer');
    container.innerHTML = '';
    Array.from(event.target.files).forEach(file => {
        const img = document.createElement('img');
        img.src = URL.createObjectURL(file);
        container.appendChild(img);
    });
});

document.getElementById('uploadMusic').addEventListener('change', function(event) {
    const audioPlayer = document.getElementById('audioPlayer');
    if (event.target.files.length > 0) {
        audioPlayer.src = URL.createObjectURL(event.target.files[0]);
        audioPlayer.play();
    }
});
